import { useEffect } from "react";
import { usePage } from "../context/PageContext";
import SchoolSelect from "../components/forms/SchoolSelect";
import PageHeader from "../components/ui/PageHeader";
import BubbleBtn from "../components/ui/BubbleBtn";

function Basics() {
  const { setPageMeta } = usePage();

  useEffect(() => {
    setPageMeta({ nextPage: "/important" });
  }, [setPageMeta]);

  return (
    <div className='page-basics page'>
      <PageHeader
        title="Let's start wit the basics"
        subtitle='Innovative options are found at all schools. First, select a grade level. Then, select your neighborhood school to explore.'
      />
      <div className='content-wrapper small'>
        <div className='button-group'>
          <BubbleBtn label='Elementry Schools' />
          <BubbleBtn label='Middle Schools' />
          <BubbleBtn label='High Schools' />
        </div>
        <SchoolSelect />
      </div>
    </div>
  );
}
export default Basics;
