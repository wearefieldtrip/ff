import { createContext, useContext, useState } from "react";

const UserFlowContext = createContext();

export const UserFlowProvider = ({ children }) => {
  const [userFlow, setUserFlow] = useState({
    gradeLevel: null,
    school: null,
    interests: [],
    outcomes: [],
  });

  const updateUserFlow = (field, value) => {
    setUserFlow((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <UserFlowContext.Provider value={{ userFlow, updateUserFlow }}>
      {children}
    </UserFlowContext.Provider>
  );
};

export const useUserFlow = () => useContext(UserFlowContext);
