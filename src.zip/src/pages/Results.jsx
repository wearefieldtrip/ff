import React from "react";

function Results() {
  return <div>Results</div>;
}

export default Results;
