function Basics() {
  return <div>Basics</div>;
}
export default Basics;
