import React from "react";

function SingleProgram() {
  return <div>Single Program</div>;
}

export default SingleProgram;
