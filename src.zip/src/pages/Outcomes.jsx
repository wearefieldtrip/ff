import React from "react";

function Outcomes() {
  return <div>Outcomes</div>;
}

export default Outcomes;
